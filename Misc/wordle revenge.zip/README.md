# challenge name

| 出题人 | 题目类型 | 题目分值 |
| :--- | :--- | :--- |
| FYHSSGSS | Misc | 300 |

## Description

Try to become the master of WORDLE and join us!

## flag

```
flag{wh1ch_WORD_do_you_ch00se_fir5t_mostly?}
```

## Hints

## Attachments

| 附件名称 | 附件描述 |
| :--- | :--- |
| /src/main.py |  |
